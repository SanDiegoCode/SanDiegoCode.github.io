package importing;

import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;

/**
 * This is the ImportManager class. This class, at startup, reads in all the required
 * files from its local directory. 
 * 
 * @author Ronak Shah
 *
 */
public class ImportManager {

	//generic title
	public static BufferedImage graphic;





	//public static BufferedImage titleScreen;

	/**
	 * Reads in all the files. MUST BE CALLED FIRST (Like absolutely first) in order to not 
	 * get apon thousands apon thousands apon thousands apon thousands apon thousands 
	 * apon thousands apon thousands apon thousands apon thousands apon thousands of java.lang.NULLPOINTEREXCEPTIONS
	 */
	public static void loadFiles(){
		try{
			graphic = ImageIO.read(ImportManager.class.getResource("graphic.png"));
			
			
		}
		catch(IOException e){
			//do nothing
		}
	}

}