import java.awt.EventQueue;
import importing.ImportManager;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.ImageIcon;


public class Main {

	private JFrame frame;
	private JTextField txtPhoneOperatingSystem;
	private JTextField txtBatteryLife;
	private JTextField txtCarrier;
	private JTextField txtPersonToCall;
	private JLabel lblPhoneOs;
	private JLabel lblBatteryoutOf;
	private JLabel lblPhoneCarriercell;
	private JLabel lblPersonToCall;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		ImportManager.loadFiles();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main window = new Main();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Main() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 600, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnCreatePhone = new JButton("Create Phone");
		btnCreatePhone.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double battery = Double.parseDouble(txtBatteryLife.getText());
				Phone newPhone = new Phone(battery, txtPhoneOperatingSystem.getText(), txtCarrier.getText(), txtPersonToCall.getText());
				newPhone.draw();
			}
		});
		btnCreatePhone.setBounds(389, 416, 186, 140);
		frame.getContentPane().add(btnCreatePhone);
		
		txtPhoneOperatingSystem = new JTextField();
		txtPhoneOperatingSystem.setBounds(204, 416, 173, 26);
		frame.getContentPane().add(txtPhoneOperatingSystem);
		txtPhoneOperatingSystem.setColumns(10);
		
		txtBatteryLife = new JTextField();
		txtBatteryLife.setBounds(204, 454, 173, 26);
		frame.getContentPane().add(txtBatteryLife);
		txtBatteryLife.setColumns(10);
		
		txtCarrier = new JTextField();
		txtCarrier.setBounds(204, 492, 173, 26);
		frame.getContentPane().add(txtCarrier);
		txtCarrier.setColumns(10);
		
		txtPersonToCall = new JTextField();
		txtPersonToCall.setBounds(204, 530, 173, 26);
		frame.getContentPane().add(txtPersonToCall);
		txtPersonToCall.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(ImportManager.graphic));
		lblNewLabel.setBounds(28, 18, 547, 386);
		frame.getContentPane().add(lblNewLabel);
		
		lblPhoneOs = new JLabel("Phone OS");
		lblPhoneOs.setBounds(6, 416, 186, 16);
		frame.getContentPane().add(lblPhoneOs);
		
		lblBatteryoutOf = new JLabel("Battery (Out of 100)");
		lblBatteryoutOf.setBounds(6, 459, 186, 16);
		frame.getContentPane().add(lblBatteryoutOf);
		
		lblPhoneCarriercell = new JLabel("Phone Carrier (Cell Network)");
		lblPhoneCarriercell.setBounds(6, 497, 186, 16);
		frame.getContentPane().add(lblPhoneCarriercell);
		
		lblPersonToCall = new JLabel("Person To Call");
		lblPersonToCall.setBounds(6, 540, 186, 16);
		frame.getContentPane().add(lblPersonToCall);
	}
}
