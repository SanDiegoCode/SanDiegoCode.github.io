import java.awt.Color;
import apcslib.DrawingTool;
import apcslib.SketchPad;

public class Phone {
    private double batteryLife;
    private String os;
    private double volume;
    private String carrier;
    private String person;
    
    public Phone (double newBattery, String newOS, String theCarrier ,String thePerson) {
        batteryLife = newBattery;
        os = newOS;
        carrier = theCarrier;
        volume = 100;
        person = thePerson;
    }
    
    public void draw() {
    	/*write your draw method here*/
    }
}